import tkinter as tk
from tkinter import filedialog
import re
import time
from threading import Thread

# ======== Gridmate Parser and Logic ========

def parse_grda(content):
    frames = []
    width = height = 0
    current_colors = []
    current_erases = []
    functions = {}
    lines = content.splitlines()

    # Remove comments
    def remove_comments(lines):
        no_comments = []
        inside_multiline = False
        for line in lines:
            line = line.strip()
            if line.startswith("--("):
                inside_multiline = True
            elif line.endswith(")") and inside_multiline:
                inside_multiline = False
            elif inside_multiline:
                continue
            elif line.startswith("--"):
                continue
            else:
                no_comments.append(line)
        return no_comments

    lines = remove_comments(lines)

    i = 0
    while i < len(lines):
        line = lines[i]

        if line.startswith("gridlength-["):
            match = re.search(r"gridlength-\[(\d+),\s*(\d+)\]", line)
            if match:
                width, height = int(match.group(1)), int(match.group(2))

        elif line.startswith("func.("):
            func_match = re.match(r"func\.\((\w+)\[(.*?)\]\)\s*\{", line)
            if func_match:
                name, params = func_match.groups()
                params = [p.strip() for p in params.split(",") if p.strip()]
                func_body = []
                i += 1
                while i < len(lines) and not lines[i].strip().endswith("}"):
                    func_body.append(lines[i].strip())
                    i += 1
                functions[name] = (params, func_body)

        elif line.startswith("rpt("):
            rpt_match = re.match(r"rpt\((\d+)\)_\{", line)
            if rpt_match:
                repeat_count = int(rpt_match.group(1))
                rpt_body = []
                i += 1
                while i < len(lines) and not lines[i].strip().endswith("}"):
                    rpt_body.append(lines[i].strip())
                    i += 1
                for _ in range(repeat_count):
                    for fline in rpt_body:
                        lines.append(fline)

        elif line.startswith("frme-["):
            frames.append((current_colors.copy(), current_erases.copy()))
            current_colors.clear()
            current_erases.clear()

        elif re.match(r"color-\[(\d+),\s*(\d+),\s*(#\w{6})\]", line):
            match = re.match(r"color-\[(\d+),\s*(\d+),\s*(#\w{6})\]", line)
            if match:
                x, y, color = int(match.group(1)), int(match.group(2)), match.group(3)
                current_colors.append((x - 1, y - 1, color))

        elif re.match(r"out-\[(\d+),\s*(\d+)\]", line):
            match = re.match(r"out-\[(\d+),\s*(\d+)\]", line)
            if match:
                x, y = int(match.group(1)), int(match.group(2))
                current_erases.append((x - 1, y - 1))

        elif re.match(r"(\w+)-\[(.*?)\]", line):
            call_match = re.match(r"(\w+)-\[(.*?)\]", line)
            name, args = call_match.groups()
            args = [eval(arg.strip()) for arg in args.split(",") if arg.strip()]
            if name in functions:
                params, func_body = functions[name]
                local_vars = dict(zip(params, args))
                for fline in func_body:
                    fline = fline
                    for var in local_vars:
                        fline = fline.replace(var, str(local_vars[var]))
                    if fline.startswith("color-["):
                        match = re.match(r"color-\[(\d+),\s*(\d+),\s*(#\w{6})\]", fline)
                        if match:
                            x, y, color = int(match.group(1)), int(match.group(2)), match.group(3)
                            current_colors.append((x - 1, y - 1, color))
                    elif fline.startswith("out-["):
                        match = re.match(r"out-\[(\d+),\s*(\d+)\]", fline)
                        if match:
                            x, y = int(match.group(1)), int(match.group(2))
                            current_erases.append((x - 1, y - 1))

        i += 1

    # Add final frame
    frames.append((current_colors.copy(), current_erases.copy()))
    return width, height, frames

# ======== Drawing Code ========

def draw_grid(canvas, width, height, colors, erases):
    size = 40
    canvas.config(width=width * size, height=height * size)
    canvas.delete("all")

    grid = [[None for _ in range(width)] for _ in range(height)]

    for x, y, color in colors:
        if 0 <= x < width and 0 <= y < height:
            grid[y][x] = color

    for x, y in erases:
        if 0 <= x < width and 0 <= y < height:
            grid[y][x] = None

    for y in range(height):
        for x in range(width):
            fill_color = grid[y][x] if grid[y][x] else "white"
            canvas.create_rectangle(
                x * size, y * size,
                (x + 1) * size, (y + 1) * size,
                fill=fill_color,
                outline="black"
            )

# ======== Animation Logic ========

def play_animation(canvas, width, height, frames):
    def run():
        for colors, erases in frames:
            draw_grid(canvas, width, height, colors, erases)
            time.sleep(0.5)

    Thread(target=run).start()

# ======== GUI ========

def open_grda():
    path = filedialog.askopenfilename(filetypes=[("Gridmate Code Files", "*.grda")])
    if not path:
        return
    with open(path, "r") as f:
        content = f.read()
    global current_width, current_height, current_frames
    current_width, current_height, current_frames = parse_grda(content)
    draw_grid(canvas, current_width, current_height, *current_frames[0])

# GUI Setup
root = tk.Tk()
root.title("Gridmate Viewer")

canvas = tk.Canvas(root, bg="white")
canvas.pack()

btn_frame = tk.Frame(root)
btn_frame.pack(pady=5)

tk.Button(btn_frame, text="Open Gridmate File", command=open_grda).pack(side="left", padx=10)
tk.Button(btn_frame, text="Play Animation", command=lambda: play_animation(canvas, current_width, current_height, current_frames)).pack(side="left", padx=10)

current_width = current_height = 0
current_frames = []

root.mainloop()
